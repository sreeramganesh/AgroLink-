import { createClient } from "@/lib/supabase/server";
import { Header } from "@/components/landing/header";
import { Footer } from "@/components/landing/footer";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapPin, Search, ShoppingCart, User } from "lucide-react";
import Link from "next/link";
import type { Product } from "@/lib/types/database";

const categoryLabels: Record<string, string> = {
  vegetables: "Vegetables",
  fruits: "Fruits",
  grains: "Grains",
  dairy: "Dairy",
  poultry: "Poultry",
  other: "Other",
};

export default async function MarketplacePage() {
  const supabase = await createClient();

  const { data: products } = await supabase
    .from("products")
    .select("*, farmer:profiles!products_farmer_id_fkey(*)")
    .eq("is_available", true)
    .gt("quantity_available", 0)
    .order("created_at", { ascending: false });

  const productList = (products || []) as Product[];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-muted/30">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary/10 to-background py-12">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-2xl text-center">
              <h1 className="mb-4 text-3xl font-bold sm:text-4xl">
                Fresh From Local Farms
              </h1>
              <p className="mb-8 text-lg text-muted-foreground">
                Discover quality produce directly from farmers in your area
              </p>
              <div className="flex flex-col gap-4 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search products..."
                    className="pl-10"
                  />
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="vegetables">Vegetables</SelectItem>
                    <SelectItem value="fruits">Fruits</SelectItem>
                    <SelectItem value="grains">Grains</SelectItem>
                    <SelectItem value="dairy">Dairy</SelectItem>
                    <SelectItem value="poultry">Poultry</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="mb-8 flex items-center justify-between">
              <h2 className="text-2xl font-bold">
                Available Products ({productList.length})
              </h2>
            </div>

            {productList.length === 0 ? (
              <div className="rounded-lg border bg-card py-16 text-center">
                <ShoppingCart className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <h3 className="mb-2 text-lg font-semibold">No Products Yet</h3>
                <p className="text-muted-foreground">
                  Check back soon for fresh produce from local farmers.
                </p>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {productList.map((product) => (
                  <Card
                    key={product.id}
                    className="group overflow-hidden transition-all hover:shadow-lg"
                  >
                    <CardHeader className="p-0">
                      <div className="relative aspect-square bg-muted">
                        <div className="flex h-full items-center justify-center text-4xl text-muted-foreground">
                          {product.category === "vegetables" && "🥬"}
                          {product.category === "fruits" && "🍎"}
                          {product.category === "grains" && "🌾"}
                          {product.category === "dairy" && "🥛"}
                          {product.category === "poultry" && "🍗"}
                          {product.category === "other" && "📦"}
                        </div>
                        <Badge className="absolute left-2 top-2">
                          {categoryLabels[product.category]}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <h3 className="mb-1 font-semibold line-clamp-1">
                        {product.name}
                      </h3>
                      {product.description && (
                        <p className="mb-2 text-sm text-muted-foreground line-clamp-2">
                          {product.description}
                        </p>
                      )}
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <User className="h-3 w-3" />
                        <span>{product.farmer?.full_name || "Unknown Farmer"}</span>
                      </div>
                      {product.farmer?.location && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span>{product.farmer.location}</span>
                        </div>
                      )}
                      <div className="mt-3 flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-primary">
                          ₹{product.price}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          /{product.unit}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {product.quantity_available} {product.unit} available
                      </p>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      <Button className="w-full" asChild>
                        <Link href={`/marketplace/${product.id}`}>
                          <ShoppingCart className="mr-2 h-4 w-4" />
                          View Details
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
