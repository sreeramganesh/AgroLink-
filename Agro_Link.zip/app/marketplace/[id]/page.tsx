"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Header } from "@/components/landing/header";
import { Footer } from "@/components/landing/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Spinner } from "@/components/ui/spinner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import {
  ArrowLeft,
  MapPin,
  Minus,
  Plus,
  ShoppingCart,
  User,
} from "lucide-react";
import Link from "next/link";
import type { Product } from "@/lib/types/database";

const categoryLabels: Record<string, string> = {
  vegetables: "Vegetables",
  fruits: "Fruits",
  grains: "Grains",
  dairy: "Dairy",
  poultry: "Poultry",
  other: "Other",
};

export default function ProductDetailPage() {
  const params = useParams();
  const router = useRouter();
  const productId = params.id as string;

  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isOrdering, setIsOrdering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    fetchProduct();
  }, [productId]);

  async function fetchProduct() {
    const supabase = createClient();
    const { data } = await supabase
      .from("products")
      .select("*, farmer:profiles!products_farmer_id_fkey(*)")
      .eq("id", productId)
      .single();

    setProduct(data as Product);
    setIsLoading(false);
  }

  async function handleOrder() {
    if (!product) return;
    setError(null);
    setIsOrdering(true);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/auth/login");
        return;
      }

      // Check user role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();

      if (profile?.role !== "buyer") {
        setError("Only buyers can place orders. Please login as a buyer.");
        return;
      }

      const totalPrice = product.price * quantity;

      const { error: orderError } = await supabase.from("orders").insert({
        buyer_id: user.id,
        farmer_id: product.farmer_id,
        product_id: product.id,
        quantity,
        total_price: totalPrice,
        delivery_address: deliveryAddress || null,
        notes: notes || null,
        status: "pending",
      });

      if (orderError) {
        setError(orderError.message);
        return;
      }

      toast.success("Order placed successfully!");
      router.push("/buyer/orders");
    } catch {
      setError("Failed to place order. Please try again.");
    } finally {
      setIsOrdering(false);
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 items-center justify-center">
          <Spinner className="h-8 w-8" />
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex flex-1 flex-col items-center justify-center gap-4">
          <h1 className="text-2xl font-bold">Product Not Found</h1>
          <Button asChild>
            <Link href="/marketplace">Back to Marketplace</Link>
          </Button>
        </main>
        <Footer />
      </div>
    );
  }

  const totalPrice = product.price * quantity;

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="container mx-auto px-4">
          <Button variant="ghost" className="mb-6" asChild>
            <Link href="/marketplace">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Marketplace
            </Link>
          </Button>

          <div className="grid gap-8 lg:grid-cols-2">
            {/* Product Image */}
            <Card>
              <CardContent className="flex aspect-square items-center justify-center p-8">
                <div className="text-9xl">
                  {product.category === "vegetables" && "🥬"}
                  {product.category === "fruits" && "🍎"}
                  {product.category === "grains" && "🌾"}
                  {product.category === "dairy" && "🥛"}
                  {product.category === "poultry" && "🍗"}
                  {product.category === "other" && "📦"}
                </div>
              </CardContent>
            </Card>

            {/* Product Details */}
            <div className="space-y-6">
              <div>
                <Badge className="mb-2">
                  {categoryLabels[product.category]}
                </Badge>
                <h1 className="text-3xl font-bold">{product.name}</h1>
                {product.description && (
                  <p className="mt-2 text-muted-foreground">
                    {product.description}
                  </p>
                )}
              </div>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <User className="h-4 w-4" />
                    <span>{product.farmer?.full_name || "Unknown Farmer"}</span>
                  </div>
                  {product.farmer?.location && (
                    <div className="mt-1 flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{product.farmer.location}</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold text-primary">
                  ₹{product.price}
                </span>
                <span className="text-xl text-muted-foreground">
                  /{product.unit}
                </span>
              </div>

              <p className="text-muted-foreground">
                {product.quantity_available} {product.unit} available
              </p>

              {/* Order Form */}
              <Card>
                <CardHeader>
                  <CardTitle>Place Order</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label>Quantity ({product.unit})</Label>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() =>
                          setQuantity((q) => Math.max(1, q - 1))
                        }
                        disabled={quantity <= 1}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <Input
                        type="number"
                        min={1}
                        max={product.quantity_available}
                        value={quantity}
                        onChange={(e) =>
                          setQuantity(
                            Math.min(
                              product.quantity_available,
                              Math.max(1, parseInt(e.target.value) || 1)
                            )
                          )
                        }
                        className="w-24 text-center"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() =>
                          setQuantity((q) =>
                            Math.min(product.quantity_available, q + 1)
                          )
                        }
                        disabled={quantity >= product.quantity_available}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Delivery Address</Label>
                    <Textarea
                      id="address"
                      placeholder="Enter your delivery address..."
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      placeholder="Any special instructions..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                    />
                  </div>

                  <div className="rounded-lg bg-muted p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Total</span>
                      <span className="text-2xl font-bold">
                        ₹{totalPrice.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    size="lg"
                    onClick={handleOrder}
                    disabled={isOrdering}
                  >
                    {isOrdering ? (
                      <Spinner className="mr-2 h-4 w-4" />
                    ) : (
                      <ShoppingCart className="mr-2 h-4 w-4" />
                    )}
                    Place Order
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
