import { createClient } from "@/lib/supabase/server";
import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { StatsCard } from "@/components/dashboard/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DollarSign,
  Package,
  ShoppingBag,
  TrendingUp,
  Store,
  Eye,
} from "lucide-react";
import Link from "next/link";
import type { Order } from "@/lib/types/database";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  shipped: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

export default async function BuyerDashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: orders } = await supabase
    .from("orders")
    .select(
      "*, product:products(*, farmer:profiles!products_farmer_id_fkey(*)), farmer:profiles!orders_farmer_id_fkey(*)"
    )
    .eq("buyer_id", user?.id)
    .order("created_at", { ascending: false })
    .limit(10);

  const orderList = (orders || []) as Order[];
  const totalOrders = orderList.length;
  const pendingOrders = orderList.filter((o) => o.status === "pending").length;
  const deliveredOrders = orderList.filter((o) => o.status === "delivered").length;
  const totalSpent = orderList
    .filter((o) => o.status === "delivered")
    .reduce((sum, o) => sum + o.total_price, 0);

  return (
    <>
      <DashboardHeader title="Dashboard" />
      <div className="flex flex-1 flex-col gap-6 p-6">
        {/* Welcome Section */}
        <div className="rounded-lg bg-gradient-to-r from-primary/10 to-primary/5 p-6">
          <h1 className="text-2xl font-bold">Welcome back!</h1>
          <p className="text-muted-foreground">
            Discover fresh produce from local farmers
          </p>
          <Button className="mt-4" asChild>
            <Link href="/marketplace">
              <Store className="mr-2 h-4 w-4" />
              Browse Marketplace
            </Link>
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Orders"
            value={totalOrders}
            description="All time orders"
            icon={ShoppingBag}
          />
          <StatsCard
            title="Pending"
            value={pendingOrders}
            description="Orders in progress"
            icon={Package}
          />
          <StatsCard
            title="Delivered"
            value={deliveredOrders}
            description="Completed orders"
            icon={TrendingUp}
          />
          <StatsCard
            title="Total Spent"
            value={`₹${totalSpent.toLocaleString()}`}
            description="On delivered orders"
            icon={DollarSign}
          />
        </div>

        {/* Recent Orders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Orders</CardTitle>
            <Button variant="outline" size="sm" asChild>
              <Link href="/buyer/orders">View All</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {orderList.length === 0 ? (
              <div className="py-12 text-center">
                <ShoppingBag className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="mb-4 text-muted-foreground">
                  You have not placed any orders yet.
                </p>
                <Button asChild>
                  <Link href="/marketplace">
                    <Store className="mr-2 h-4 w-4" />
                    Start Shopping
                  </Link>
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Farmer</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orderList.slice(0, 5).map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">
                        {order.product?.name || "Unknown"}
                      </TableCell>
                      <TableCell>
                        {order.farmer?.full_name || "Unknown"}
                      </TableCell>
                      <TableCell>
                        {order.quantity} {order.product?.unit}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={statusColors[order.status]}
                        >
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        ₹{order.total_price.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/buyer/orders/${order.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Button asChild>
                <Link href="/marketplace">
                  <Store className="mr-2 h-4 w-4" />
                  Browse Products
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/buyer/orders">
                  <Eye className="mr-2 h-4 w-4" />
                  Track Orders
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
