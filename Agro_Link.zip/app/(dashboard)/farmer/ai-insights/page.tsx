"use client";

import { useState } from "react";
import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Spinner } from "@/components/ui/spinner";
import { Badge } from "@/components/ui/badge";
import {
  Bot,
  TrendingUp,
  CloudSun,
  DollarSign,
  Leaf,
  Send,
  Sparkles,
} from "lucide-react";

const quickInsights = [
  {
    icon: TrendingUp,
    title: "Market Trends",
    description: "Tomato prices expected to rise 15% next month due to seasonal demand",
    badge: "High Demand",
    badgeColor: "bg-green-100 text-green-800",
  },
  {
    icon: CloudSun,
    title: "Weather Alert",
    description: "Moderate rainfall expected this week. Consider harvesting ready crops early.",
    badge: "Advisory",
    badgeColor: "bg-yellow-100 text-yellow-800",
  },
  {
    icon: DollarSign,
    title: "Pricing Suggestion",
    description: "Your potato prices are 10% below market average. Consider adjusting.",
    badge: "Optimize",
    badgeColor: "bg-blue-100 text-blue-800",
  },
  {
    icon: Leaf,
    title: "Crop Recommendation",
    description: "Based on soil data, consider planting spinach for better yield this season.",
    badge: "Suggestion",
    badgeColor: "bg-purple-100 text-purple-800",
  },
];

export default function AIInsightsPage() {
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);

  async function handleAskAI(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setResponse(null);

    // Simulate AI response (in production, this would call the AI API)
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setResponse(
      `Based on your query about "${query}", here are my recommendations:\n\n` +
      `1. **Market Analysis**: Current market conditions suggest favorable pricing for your products. Consider maintaining your current inventory levels.\n\n` +
      `2. **Best Practices**: For optimal results, ensure proper storage conditions and timely harvesting.\n\n` +
      `3. **Pricing Strategy**: Your current pricing appears competitive. Monitor competitor prices weekly for adjustments.\n\n` +
      `Would you like more specific information about any of these points?`
    );
    setIsLoading(false);
  }

  return (
    <>
      <DashboardHeader
        title="AI Insights"
        breadcrumbs={[
          { label: "Dashboard", href: "/farmer/dashboard" },
          { label: "AI Insights" },
        ]}
      />
      <div className="flex flex-1 flex-col gap-6 p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Bot className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">AI Insights</h1>
            <p className="text-muted-foreground">
              Get AI-powered recommendations for your farming business
            </p>
          </div>
        </div>

        {/* Quick Insights Grid */}
        <div className="grid gap-4 md:grid-cols-2">
          {quickInsights.map((insight) => (
            <Card key={insight.title}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <insight.icon className="h-5 w-5 text-primary" />
                    <CardTitle className="text-base">{insight.title}</CardTitle>
                  </div>
                  <Badge variant="secondary" className={insight.badgeColor}>
                    {insight.badge}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {insight.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* AI Chat Interface */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Ask AI Assistant
            </CardTitle>
            <CardDescription>
              Ask questions about pricing, market trends, crop planning, or any farming-related topic
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleAskAI} className="space-y-4">
              <Textarea
                placeholder="e.g., What is the best time to sell tomatoes? How can I improve my crop yield?"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="min-h-[100px]"
                disabled={isLoading}
              />
              <Button type="submit" disabled={isLoading || !query.trim()}>
                {isLoading ? (
                  <Spinner className="mr-2 h-4 w-4" />
                ) : (
                  <Send className="mr-2 h-4 w-4" />
                )}
                Ask AI
              </Button>
            </form>

            {response && (
              <div className="rounded-lg bg-muted p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Bot className="h-5 w-5 text-primary" />
                  <span className="font-medium">AI Response</span>
                </div>
                <div className="prose prose-sm max-w-none whitespace-pre-wrap text-muted-foreground">
                  {response}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tips */}
        <Card>
          <CardHeader>
            <CardTitle>Tips for Better Results</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-inside list-disc space-y-2 text-sm text-muted-foreground">
              <li>Be specific about your crops and location for personalized advice</li>
              <li>Ask about seasonal trends and market predictions</li>
              <li>Get pricing recommendations based on current market data</li>
              <li>Request crop rotation and soil health suggestions</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
