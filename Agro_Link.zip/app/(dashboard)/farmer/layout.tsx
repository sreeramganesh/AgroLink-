import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { SidebarInset } from "@/components/ui/sidebar";
import { FarmerSidebar } from "@/components/dashboard/farmer-sidebar";
import type { Profile } from "@/lib/types/database";

export default async function FarmerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (!profile || profile.role !== "farmer") {
    redirect("/buyer/dashboard");
  }

  return (
    <>
      <FarmerSidebar profile={profile as Profile} />
      <SidebarInset>{children}</SidebarInset>
    </>
  );
}
