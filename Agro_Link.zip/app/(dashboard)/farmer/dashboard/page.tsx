import { createClient } from "@/lib/supabase/server";
import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { StatsCard } from "@/components/dashboard/stats-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DollarSign,
  Package,
  ShoppingCart,
  TrendingUp,
  Plus,
  Eye,
} from "lucide-react";
import Link from "next/link";
import type { Order, Product } from "@/lib/types/database";

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  shipped: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

export default async function FarmerDashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Fetch stats
  const [productsResult, ordersResult] = await Promise.all([
    supabase
      .from("products")
      .select("*", { count: "exact" })
      .eq("farmer_id", user?.id),
    supabase
      .from("orders")
      .select("*, product:products(*), buyer:profiles!orders_buyer_id_fkey(*)")
      .eq("farmer_id", user?.id)
      .order("created_at", { ascending: false })
      .limit(5),
  ]);

  const products = (productsResult.data || []) as Product[];
  const orders = (ordersResult.data || []) as Order[];
  const totalProducts = productsResult.count || 0;
  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o) => o.status === "pending").length;
  const totalRevenue = orders
    .filter((o) => o.status === "delivered")
    .reduce((sum, o) => sum + o.total_price, 0);

  return (
    <>
      <DashboardHeader title="Dashboard" />
      <div className="flex flex-1 flex-col gap-6 p-6">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Products"
            value={totalProducts}
            description="Active listings"
            icon={Package}
          />
          <StatsCard
            title="Total Orders"
            value={totalOrders}
            description="All time orders"
            icon={ShoppingCart}
          />
          <StatsCard
            title="Pending Orders"
            value={pendingOrders}
            description="Awaiting confirmation"
            icon={TrendingUp}
          />
          <StatsCard
            title="Total Revenue"
            value={`₹${totalRevenue.toLocaleString()}`}
            description="From delivered orders"
            icon={DollarSign}
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Recent Orders */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent Orders</CardTitle>
              <Button variant="outline" size="sm" asChild>
                <Link href="/farmer/orders">View All</Link>
              </Button>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <p className="py-8 text-center text-muted-foreground">
                  No orders yet. Start by adding products!
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.slice(0, 5).map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">
                          {order.product?.name || "Unknown"}
                        </TableCell>
                        <TableCell>{order.quantity}</TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={statusColors[order.status]}
                          >
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{order.total_price.toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* My Products */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>My Products</CardTitle>
              <Button size="sm" asChild>
                <Link href="/farmer/products/new">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {products.length === 0 ? (
                <div className="py-8 text-center">
                  <p className="mb-4 text-muted-foreground">
                    You have not added any products yet.
                  </p>
                  <Button asChild>
                    <Link href="/farmer/products/new">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Your First Product
                    </Link>
                  </Button>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.slice(0, 5).map((product) => (
                      <TableRow key={product.id}>
                        <TableCell className="font-medium">
                          {product.name}
                        </TableCell>
                        <TableCell>
                          ₹{product.price}/{product.unit}
                        </TableCell>
                        <TableCell>{product.quantity_available}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              product.is_available ? "default" : "secondary"
                            }
                          >
                            {product.is_available ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Button asChild>
                <Link href="/farmer/products/new">
                  <Plus className="mr-2 h-4 w-4" />
                  Add New Product
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/farmer/orders">
                  <Eye className="mr-2 h-4 w-4" />
                  View Orders
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/farmer/ai-insights">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  AI Insights
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
