import Link from "next/link";
import Image from "next/image";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Left side - Branding */}
      <div className="hidden bg-primary lg:flex lg:flex-col lg:justify-between lg:p-12">
        <Link href="/" className="flex items-center gap-3">
          <Image
            src="/images/logo.png"
            alt="AGROLINK Logo"
            width={48}
            height={48}
            className="rounded-full bg-white p-1"
          />
          <span className="text-2xl font-bold text-primary-foreground">
            AGROLINK
          </span>
        </Link>
        <div className="space-y-4">
          <h1 className="text-3xl font-bold leading-tight text-primary-foreground">
            Connecting Farmers
            <br />
            Directly to Buyers
          </h1>
          <p className="max-w-md text-primary-foreground/80">
            Join thousands of farmers and buyers who are transforming
            agriculture through direct trade. Fresh produce, fair prices,
            sustainable future.
          </p>
        </div>
        <p className="text-sm text-primary-foreground/60">
          &copy; {new Date().getFullYear()} AGROLINK. All rights reserved.
        </p>
      </div>

      {/* Right side - Auth Form */}
      <div className="flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile header */}
          <div className="mb-8 flex justify-center lg:hidden">
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/images/logo.png"
                alt="AGROLINK Logo"
                width={40}
                height={40}
                className="rounded-full"
              />
              <span className="text-xl font-bold text-primary">AGROLINK</span>
            </Link>
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
