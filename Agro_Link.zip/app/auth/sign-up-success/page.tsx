import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { CheckCircle2, Mail } from "lucide-react";

export default function SignUpSuccessPage() {
  return (
    <Card className="border-0 shadow-none lg:border lg:shadow-sm">
      <CardHeader className="space-y-1 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
          <CheckCircle2 className="h-8 w-8 text-primary" />
        </div>
        <CardTitle className="text-2xl font-bold">Check your email</CardTitle>
        <CardDescription>
          We sent you a confirmation link to complete your registration
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="rounded-lg bg-muted p-4">
          <div className="flex items-start gap-3">
            <Mail className="mt-0.5 h-5 w-5 text-muted-foreground" />
            <div className="space-y-1">
              <p className="text-sm font-medium">Confirmation email sent</p>
              <p className="text-sm text-muted-foreground">
                Click the link in your email to verify your account and get
                started with AGROLINK.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <p className="text-center text-sm text-muted-foreground">
            {"Didn't receive the email? Check your spam folder or"}
          </p>
          <Button variant="outline" className="w-full" asChild>
            <Link href="/auth/sign-up">Try signing up again</Link>
          </Button>
        </div>

        <div className="text-center">
          <Link
            href="/auth/login"
            className="text-sm text-primary hover:underline"
          >
            Back to login
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
