import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

export default function AuthErrorPage() {
  return (
    <Card className="border-0 shadow-none lg:border lg:shadow-sm">
      <CardHeader className="space-y-1 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
          <AlertCircle className="h-8 w-8 text-destructive" />
        </div>
        <CardTitle className="text-2xl font-bold">
          Authentication Error
        </CardTitle>
        <CardDescription>
          Something went wrong during authentication
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <p className="text-center text-sm text-muted-foreground">
          This could be due to an expired link, an invalid token, or a network
          issue. Please try again.
        </p>

        <div className="flex flex-col gap-3">
          <Button asChild>
            <Link href="/auth/login">Back to Login</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/auth/sign-up">Create New Account</Link>
          </Button>
        </div>

        <div className="text-center">
          <Link href="/" className="text-sm text-primary hover:underline">
            Return to Home
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
