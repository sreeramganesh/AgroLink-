import { ClipboardList, Package, Search, UserPlus } from "lucide-react";

const steps = [
  {
    icon: UserPlus,
    step: "01",
    title: "Create Account",
    description:
      "Sign up as a farmer or buyer. Farmers get a unique ID and can start listing products immediately.",
  },
  {
    icon: ClipboardList,
    step: "02",
    title: "List or Browse",
    description:
      "Farmers list their fresh produce with photos and pricing. Buyers browse the marketplace for what they need.",
  },
  {
    icon: Search,
    step: "03",
    title: "Connect & Order",
    description:
      "Buyers place orders directly with farmers. Real-time messaging enables smooth communication.",
  },
  {
    icon: Package,
    step: "04",
    title: "Deliver & Receive",
    description:
      "Farmers fulfill orders and arrange delivery. Both parties rate the transaction for quality assurance.",
  },
];

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      className="bg-muted/50 py-20 lg:py-32"
    >
      <div className="container mx-auto px-4">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight sm:text-4xl">
            How AGROLINK Works
          </h2>
          <p className="text-lg text-muted-foreground">
            Getting started is easy. Follow these simple steps to begin your
            journey with AGROLINK.
          </p>
        </div>
        <div className="relative">
          {/* Connection line */}
          <div className="absolute left-1/2 top-0 hidden h-full w-0.5 -translate-x-1/2 bg-border lg:block" />
          
          <div className="grid gap-8 lg:gap-12">
            {steps.map((item, index) => (
              <div
                key={item.step}
                className={`flex flex-col items-center gap-6 lg:flex-row ${
                  index % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                <div
                  className={`flex-1 ${
                    index % 2 === 0 ? "lg:text-right" : "lg:text-left"
                  }`}
                >
                  <div
                    className={`inline-flex flex-col gap-2 ${
                      index % 2 === 0 ? "lg:items-end" : "lg:items-start"
                    }`}
                  >
                    <span className="text-sm font-semibold text-primary">
                      Step {item.step}
                    </span>
                    <h3 className="text-xl font-bold">{item.title}</h3>
                    <p className="max-w-md text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
                <div className="relative z-10 flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg">
                  <item.icon className="h-7 w-7" />
                </div>
                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
