import {
  Bot,
  Clock,
  DollarSign,
  Leaf,
  MapPin,
  Shield,
  Smartphone,
  TrendingUp,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: Leaf,
    title: "Fresh from Farm",
    description:
      "Get produce directly from local farms, ensuring maximum freshness and quality for your table.",
  },
  {
    icon: DollarSign,
    title: "Fair Pricing",
    description:
      "Farmers set their own prices, eliminating middlemen and ensuring fair compensation for their work.",
  },
  {
    icon: Bot,
    title: "AI-Powered Insights",
    description:
      "Smart recommendations for farmers on pricing, demand trends, and crop planning using AI technology.",
  },
  {
    icon: MapPin,
    title: "Local Discovery",
    description:
      "Find farmers in your area and support local agriculture while reducing carbon footprint.",
  },
  {
    icon: Shield,
    title: "Secure Transactions",
    description:
      "Safe and secure payment processing with buyer protection and order tracking.",
  },
  {
    icon: Clock,
    title: "Real-time Updates",
    description:
      "Stay informed with instant notifications on orders, deliveries, and new products.",
  },
  {
    icon: Smartphone,
    title: "Easy to Use",
    description:
      "Simple, intuitive interface designed for both farmers and buyers of all tech levels.",
  },
  {
    icon: TrendingUp,
    title: "Market Analytics",
    description:
      "Access market trends and insights to make informed decisions about buying and selling.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight sm:text-4xl">
            Why Choose AGROLINK?
          </h2>
          <p className="text-lg text-muted-foreground">
            We provide the tools and platform to make agricultural trade simple,
            fair, and sustainable for everyone involved.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="group transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <feature.icon className="h-6 w-6" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
