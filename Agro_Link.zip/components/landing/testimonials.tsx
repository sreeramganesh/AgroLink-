import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "AGROLINK changed my farming business completely. I now sell directly to customers and earn 40% more than before. The AI pricing suggestions are incredibly helpful.",
    name: "Ramesh Kumar",
    role: "Vegetable Farmer",
    location: "Punjab",
    initials: "RK",
  },
  {
    quote:
      "As a restaurant owner, getting fresh produce directly from farmers has improved our food quality significantly. The platform is easy to use and reliable.",
    name: "Priya Sharma",
    role: "Restaurant Owner",
    location: "Delhi",
    initials: "PS",
  },
  {
    quote:
      "The real-time notifications and order tracking make managing my farm store so much easier. I can focus on growing quality produce instead of marketing.",
    name: "Mohammed Ali",
    role: "Organic Farmer",
    location: "Karnataka",
    initials: "MA",
  },
  {
    quote:
      "Finding local organic produce was always a challenge until I discovered AGROLINK. Now I know exactly where my food comes from and support local farmers.",
    name: "Anita Desai",
    role: "Health-Conscious Buyer",
    location: "Mumbai",
    initials: "AD",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="mx-auto mb-16 max-w-2xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight sm:text-4xl">
            What Our Community Says
          </h2>
          <p className="text-lg text-muted-foreground">
            Hear from farmers and buyers who have transformed their agricultural
            experience with AGROLINK.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.name} className="relative">
              <CardContent className="pt-6">
                <Quote className="absolute right-6 top-6 h-8 w-8 text-primary/20" />
                <p className="mb-6 text-muted-foreground">
                  &ldquo;{testimonial.quote}&rdquo;
                </p>
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12 bg-primary/10">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {testimonial.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {testimonial.role} • {testimonial.location}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
