import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sprout, Store } from "lucide-react";

export function CTA() {
  return (
    <section className="bg-primary py-20 lg:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl">
            Ready to Transform Your Agricultural Journey?
          </h2>
          <p className="mb-8 text-lg text-primary-foreground/80">
            Join thousands of farmers and buyers who are already benefiting from
            direct agricultural trade. Start your journey today.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="w-full sm:w-auto"
            >
              <Link href="/auth/sign-up?role=farmer">
                <Sprout className="mr-2 h-5 w-5" />
                Join as Farmer
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="w-full border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground sm:w-auto"
            >
              <Link href="/auth/sign-up?role=buyer">
                <Store className="mr-2 h-5 w-5" />
                Join as Buyer
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
