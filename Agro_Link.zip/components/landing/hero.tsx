import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { ArrowRight, Leaf, ShoppingCart, Users } from "lucide-react";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-accent/50 to-background py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="flex flex-col gap-6">
            <div className="inline-flex w-fit items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
              <Leaf className="h-4 w-4" />
              Farm Fresh, Direct to You
            </div>
            <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              Connecting Farmers Directly to Buyers
            </h1>
            <p className="max-w-xl text-pretty text-lg text-muted-foreground">
              AGROLINK bridges the gap between local farmers and consumers.
              Get fresh produce at fair prices while supporting sustainable
              agriculture in your community.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <Button size="lg" asChild>
                <Link href="/auth/sign-up">
                  Start Selling
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/marketplace">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Browse Marketplace
                </Link>
              </Button>
            </div>
            <div className="flex items-center gap-8 pt-4">
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">500+</span>
                <span className="text-sm text-muted-foreground">Active Farmers</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">10K+</span>
                <span className="text-sm text-muted-foreground">Happy Buyers</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-primary">50K+</span>
                <span className="text-sm text-muted-foreground">Orders Delivered</span>
              </div>
            </div>
          </div>
          <div className="relative hidden lg:block">
            <div className="relative h-[500px] w-full">
              <div className="absolute right-0 top-0 h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
              <div className="absolute bottom-0 left-0 h-64 w-64 rounded-full bg-secondary/30 blur-3xl" />
              <Image
                src="/images/logo.png"
                alt="AGROLINK - Farmers and Buyers"
                width={400}
                height={400}
                className="relative z-10 mx-auto drop-shadow-2xl"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
