export type UserRole = "farmer" | "buyer";

export type ProductStatus = "available" | "sold" | "pending";

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "shipped"
  | "delivered"
  | "cancelled";

export type NotificationType = "info" | "order" | "alert" | "success";

export interface Profile {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: UserRole;
  farmer_id: string | null;
  location: string | null;
  created_at: string;
  // Alias for consistency
  full_name?: string;
}

export interface Product {
  id: string;
  farmer_id: string;
  crop: string;
  description: string | null;
  price: number;
  unit: string;
  quantity: number;
  image_url: string | null;
  location: string;
  status: ProductStatus;
  created_at: string;
  updated_at: string;
  // Joined fields
  farmer?: Profile;
  // Aliases for component compatibility
  name?: string;
  quantity_available?: number;
  is_available?: boolean;
  category?: string;
}

export interface Order {
  id: string;
  buyer_id: string;
  farmer_id: string;
  product_id: string;
  quantity: number;
  total_price: number;
  status: OrderStatus;
  delivery_location: string | null;
  created_at: string;
  updated_at: string;
  // Joined fields
  product?: Product;
  buyer?: Profile;
  farmer?: Profile;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  read: boolean;
  created_at: string;
  // Alias
  is_read?: boolean;
}

export interface DashboardStats {
  totalProducts: number;
  totalOrders: number;
  totalRevenue: number;
  pendingOrders: number;
}
